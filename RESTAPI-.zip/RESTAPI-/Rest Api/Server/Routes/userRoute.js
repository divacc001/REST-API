const express = require("express");
const userRoute = express.Router();
const { getUsers, getOneUser, putUser, postUser, deleteUser } = require("../Controllers/userController")

// GET :  RETURN ALL USERS 
userRoute.get("/users", getUsers)
// GET : RETURN A USER BY ID 
userRoute.get("/users/:id", getOneUser);
// PUT : EDIT A USER BY ID 
userRoute.put("/users/:id", putUser)
// POST :  ADD A NEW USER TO THE DATABASE 
userRoute.post("/users", postUser)
// DELETE : REMOVE A USER BY ID 
userRoute.delete("/users/:id", deleteUser);


module.exports=userRoute;



















